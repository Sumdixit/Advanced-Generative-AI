# Sample Questions to test the Nestlé HR Assistant

1. What are the key elements that define Total Rewards at Nestlé?
2. How does Nestlé approach employment conditions and work-life balance?
3. Who has the prime responsibility for people matters at Nestlé?
4. How does Nestlé handle training and learning for employees?
5. Explain how promotions and performance management work at Nestlé.
6. What is Nestlé’s stance on employee relations and collective bargaining?
7. What does “A flexible and dynamic organisation” mean in the Nestlé HR policy?
8. From the Gradio docs, what are the core arguments of `gr.Interface`?
9. From the course brief, what are the main steps expected in this project?
10. If the policy does not specify something, how should the assistant respond?
